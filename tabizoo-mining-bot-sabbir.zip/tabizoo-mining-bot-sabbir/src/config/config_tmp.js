export class Config {
  static TELEGRAM_APP_ID = 24588335; // YOUR APP ID EX : 324893724923
  static TELEGRAM_APP_HASH = "063bda2718dd2feb99262420d9392d05"; // YOUR APP HASH EX: "aslkfjkalsjflkasf"
}
